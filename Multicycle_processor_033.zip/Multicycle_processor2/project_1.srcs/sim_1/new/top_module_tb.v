`timescale 1ns / 1ps

module top_module_tb();

    // 1. Testbench Signals
    reg clk;
    reg rst;
    wire [31:0] pc;
    wire [31:0] instruction;
    wire [4:0]  rs1, rs2, rd;

    // 2. Instantiate the Top Module (UUT)
    top_module uut (
        .clk(clk), 
        .rst(rst), 
        .pc(pc), 
        .instruction(instruction), 
        .rs1(rs1), 
        .rs2(rs2), 
        .rd(rd)
    );

    // 3. Clock Generation (50MHz Clock -> 20ns Period)
    always #10 clk = ~clk;


    // 4. Stimulus Process
    initial begin
        // Initialize inputs
        clk = 0;
        rst = 1;

        // Reset state ko 30ns tak maintain rakhein taake system clean clear ho jaye
        #20;
        rst = 0; 
        
        $display("==========================================================");
        $display("         RISC-V MULTICYCLE PROCESSOR SIMULATION           ");
        $display("==========================================================");
        
        // Simulation runtime: 600ns tak chalayein taake aapki inst_mem.v mein maujood
        // saari instructions (addi, sub, sw, lw, jal) cycle-by-cycle execute ho sakein.
        #700;

        $display("==========================================================");
        $display("               SIMULATION COMPLETED SUCCESSFULLY          ");
        $display("==========================================================");
        $finish;
    end
      
    // 5. Automatic State & Jump Monitor Console Logging

    initial begin
        $timeformat(-9, 0, " ns", 10);
        forever begin
            @(posedge clk);
          //  #5; 
            if (!rst) begin
                $display("Time: %t | PC: 0x%h | Instruction: 0x%h | FSM State: S%0d | RegWrite: %b | PCWrite: %b", 
                         $time, pc, instruction, uut.FSMcontrol.state, uut.RegWrite, uut.PCWrite);
                
                // Agar FSM JAL state (S9) mein ho to warning/info print karein
                if (uut.FSMcontrol.state == 4'd9) begin
                    $display(">>> [JAL DETECTED] Target JUMP Address Calculated: 0x%h <<<", uut.result);
                end
            end
        end
    end

endmodule